import scrapy
from ssense.items import DmozItem, BrandItem

class SsenseSpider(scrapy.Spider):
    name = "ssense"
    allowed_domains = ["www.ssense.com"]
    start_urls = [
        "http://www.ssense.com/en-us/men"
    ]

    def parse(self, response):        
        for sel in response.css(".browsing-product-description"):
        	item = DmozItem()
        	item['designer'] = sel.css('.product-designer').xpath('text()').extract()
        	item['productName'] = sel.css('.product-name').xpath('text()').extract()
        	item['price'] = sel.css('p.product-price').xpath('text()').re('\$[0-9|,]+')
        	yield item

        for brand in response.css("div.section a"):
        	item = BrandItem()
        	item['name'] = brand.xpath('text()').extract()
        	item['href'] = brand.xpath('@href').extract()
        	yield scrapy.Request("http://www.ssense.com" + item['href'][0], callback=self.parse)