BOT_NAME = 'SSENSE'

SPIDER_MODULES = ['ssense.spiders']
NEWSPIDER_MODULE = 'ssense.spiders'
