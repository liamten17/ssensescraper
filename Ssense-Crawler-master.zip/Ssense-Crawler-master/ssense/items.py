import scrapy


class DmozItem(scrapy.Item):
    designer = scrapy.Field()
    productName = scrapy.Field()
    price = scrapy.Field()


class BrandItem(scrapy.Item):
	name = scrapy.Field()
	href = scrapy.Field()