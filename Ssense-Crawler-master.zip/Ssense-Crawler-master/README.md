# Ssense-Crawler

Use Scrapy to scrawl all the items in SSENSE.com

pulled item's price, name and designer to items.json
